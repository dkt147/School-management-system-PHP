     <link href="../admin/bootstrap/css/admin_background.css" rel="stylesheet" media="screen"/>
<link rel="shortcut icon" href="../admin/images/logo.png" />
	 <div class="span3" id="sidebar">
	              <img id="admin_avatar" class="img-circle" src="<?php echo $row['../admin/adminthumbnails']; ?>">
	                        <ul class="nav nav-list bs-docs-sidenav nav-collapse collapse">
                           <li class="active"> 
						   <a href="../admin/dashboard.php"><i class="icon-chevron-right"></i><i class="icon-home"></i>&nbsp;Dashboard</a> 
						   </li>
						 
											
						 <li>						
						    <a href="javascript:;" role="button" class="dropdown-toggle" data-toggle="collapse" data-target="#bs"><i class="icon-chevron-right"></i><i class="icon-user"></i>Student Detail
						    <div class="muted pull-right"><i class="caret"></i></div></a>					
						    <ul id="bs" class="collapse">						
                            <li class="">
                            <a href="#"><i class="icon-chevron-right"></i><i class="icon-user"></i> Results</a>
                            </li>
                            <li class="">
                            <a href="#"><i class="icon-chevron-right"></i><i class="icon-folder-open-alt"></i> Fee Report</a>
                            </li> 
						    <li>
                            <a href="#"><i class="icon-chevron-right"></i><i class="icon-laptop"></i>Fee Structure </a>		
							</a>
                            </li>						
						    <li>
                            <a href="#"><i class="icon-chevron-right"></i><i class="icon-laptop"></i> add here.
							
							</a>
                            </li>
							<li>
                            <a href="#"><i class="icon-chevron-right"></i><i class="icon-remove-sign"></i>  add here
							
							</a>
                            </li>						   							
						    </ul>
						</li>
						
                         <!------/.* manage location sidebar*------->	
					    <li>						
					    <a href="javascript:;" role="button" class="dropdown-toggle" data-toggle="collapse" data-target="#bs1"><i class="icon-chevron-right"></i><i class="icon-globe"></i>&nbsp;</a><a href="javascript:;" role="button" class="dropdown-toggle" data-toggle="collapse" data-target="#bs2"> </a></li>
					    <li><a href="javascript:;" role="button" class="dropdown-toggle" data-toggle="collapse" data-target="#bs2">
					    <div class="muted pull-right"><i class="caret"></i></div></a>						
						    <ul id="bs2" class="collapse">						
                            <li class="">
                            <a href="../admin/staff_user.php"><i class="icon-chevron-right"></i><i class="icon-user"></i></a><a href="javascript:;" role="button" class="dropdown-toggle" data-toggle="collapse" data-target="#bs3"></a></li>
						    </ul>
					    </li>
					    <li><a href="javascript:;" role="button" class="dropdown-toggle" data-toggle="collapse" data-target="#bs3">
					    <div class="muted pull-right"><i class="caret"></i></div></a>						
						    <ul id="bs3" class="collapse">						
                            <li class="">
                            <a href="../admin/activity_log.php"><i class="icon-chevron-right"></i><i class="icon-file"></i></a></li>
						    </ul>
						</li>
						
					  <!------/.* notification sidebar*------->
				    <li class=""><a href="#">
			        
		            </a>
			            </li>
						
                         <li class="">
                           <a href="javascript:;" role="button" class="dropdown-toggle" data-toggle="collapse" data-target="#bs4"><i class="icon-chevron-right"></i><i class="icon-search icon-large"></i>
                           <div class="muted pull-right"><i class="caret"></i></div></a>
                           </a>
                           <ul id="bs4" class="collapse">
                           
                                                 
                           </ul>
                    </li>
                  </ul>					
													
    </div>