<div class="setfooter">
		<footer >
           <p align="center">&copy; ST. LUKES BOYS SEC SCH. 2015 </p>
		  <p align="center"> Powered by: <a href="https://geeksourcecodes.com/">geeksourcecodes</a></p>
		  		  <h6 align="center">Follow Us :</h6> <p align="center">
<a href="#" ><img src="images/facebook.png" id=social /></a>
<a href="#"><img src="images/twitter.png" id=social /></a>
<a href="#"><img src="images/linkedin.png"id=social  /></a>
<a href="#"><img src="images/youtube.png" id=social /></a>
<a href="#"><img src="images/gmail.png" id=social /></a></p>
</div>
        <footer>
</div>