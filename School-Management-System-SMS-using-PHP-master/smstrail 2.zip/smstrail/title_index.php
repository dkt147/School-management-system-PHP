				
	<div class="row-fluid">
			<div class="span12"></div>
				  <div class="row-fluid">
						<div class="span10">
                        <div class="span12">
							<div class="motto">
																										
							</div>											
						</div>	<br>
                        <br>
						<img class="index_logo" src="admin/images/sclogo.png">
						</div>	
												
				  </div>		   							
    </div>	
				