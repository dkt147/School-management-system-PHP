<?php
        include('admin/lib/dbcon.php');
		dbcon(); 
		session_start();	
		$username = $_POST['username'];
		$password = $_POST['password'];
		
		/*................................................ admin .....................................................*/
			$query = "SELECT * FROM admin WHERE username='$username' AND password='$password'";
			$result = mysql_query($query)or die(mysql_error());
			$row = mysql_fetch_array($result);
			$num_row = mysql_num_rows($result);
			
		/*................................................... Staff ..............................................*/
		$query_staff = mysql_query("SELECT * FROM staff WHERE username='$username' AND password='$password'")or die(mysql_error());
		$num_row_staff = mysql_num_rows($query_staff);
		$row_staff = mysql_fetch_array($query_staff);
		
		if( $num_row > 0 ) { 
		$_SESSION['id']=$row['admin_id'];
		echo 'true_admin';
		
		mysql_query("insert into user_log (username,login_date,admin_id)values('$username',NOW(),".$row['admin_id'].")")or die(mysql_error());
		
		}else if ($num_row_staff > 0){
		$_SESSION['staff']=$row_staff['staff_id'];
		echo 'true';
		
		mysql_query("insert into user_log (username,login_date,staff_id)values('$username',NOW(),".$row_staff['staff_id'].")")or die(mysql_error());
		
		 }else{ 
				echo 'false';
		}	
				
		?>