<div class="navbar navbar-fixed-top navbar-inverse">
           <div class="navbar-inner">
               <div class="container-fluid">
					<a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse"> <span class="icon-bar"></span>
						<span class="icon-bar"></span>
						<span class="icon-bar"></span>
					</a>
                   <a class="brand" href="#">St.Lukes Boys School Management System</a>
							<div class="nav-collapse collapse">
								<ul class="nav pull-right">
	

								</ul>
							</div>
                   <!--/.nav-collapse -->
               </div>
           </div>
</div>
	